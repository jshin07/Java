class PythagoreanTest{
    public static void main(String[] args){
        Pythagorean iD = new Pythagorean();
        double c = iD.calculateHypotenuse(3,4);
        System.out.println(c);
    }
}
