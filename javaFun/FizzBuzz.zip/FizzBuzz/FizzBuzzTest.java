class FizzBuzzTest {
    public static void main(String[] args) {
        FizzBuzz iD = new FizzBuzz();
        String fizzBuzz = iD.fizzBuzz(15);
        System.out.println(fizzBuzz);
    }
}
