public class GorillaTest{
    public static void main(String[] args) {
        Gorilla gorilla= new Gorilla();
        gorilla.throwFood();
        gorilla.throwFood();
        gorilla.throwFood();
        gorilla.eatBananas();
        gorilla.eatBananas();
        gorilla.climb();

        gorilla.displayEnergy();
    }
}
