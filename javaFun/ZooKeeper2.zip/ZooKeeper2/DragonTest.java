public class DragonTest{
    public static void main(String[] args) {
        Dragon dragon= new Dragon();
        dragon.displayEnergy();
        dragon.attackTown();
        dragon.attackTown();
        dragon.attackTown();

        dragon.eatHuman();
        dragon.eatHuman();

        dragon.fly();
        dragon.fly();
        dragon.displayEnergy();
    }
}
