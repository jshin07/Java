import java.util.ArrayList;

public class PuzzleJavaTest {
    public static void main(String[] args) {
        PuzzleJava iD= new PuzzleJava();
        // int[] sumarray = {3,5,1,2,7,9,8,13,25,32};
        // System.out.println(iD.getSum(sumarray));

    //     String[] names = {"Nancy", "Jinichi", "Fujibayashi", "Momochi", "Ishikawa"};
    //     System.out.println("This is name greather than 5 "+ iD.japNames(names));

    //     char[] alphabetArray = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    //     iD.alphabets(alphabetArray);

    // iD.tenRandom();

    // iD.tenRandomPlus();

    // iD.randString();

    iD.randStringArray();

    }


}
