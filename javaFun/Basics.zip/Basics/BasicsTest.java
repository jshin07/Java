class BasicsTest {
    public static void main(String[] args) {
        Basics iD = new Basics();
        // iD.print1To255();

        // iD.printOdd1To255();

        // iD.sum();

        // int[] testArray1 = {1,3,5,7,9,13};
        // iD.iterateArray(testArray1);

        // int[] testArray2 = {-3, -10,3,-5, -7};
        // iD.findMax(testArray2);

        // int[] testArray3 ={2, 10, 3};
        // iD.getAverage(testArray3);

        // iD.oddNumbers();

        // int[] testArray4 = {1, 3, 5, 7};
        // System.out.println(iD.greaterThanY(testArray4,3));

        // int[] testArray5= {1, 5, 10, -2};
        // iD.squareValue(testArray5);

        // int[] testArray6= {1, 5, 10, -2};
        // iD.eliminateNegNumbers(testArray6);

        // int[] testArray7= {1, 5, 10, -2};
        // iD.maxMinAverage(testArray7);

        int[] testArray8 = {1, 5, 10, 7, -2};
        iD.shiftValues(testArray8);
    }
}
