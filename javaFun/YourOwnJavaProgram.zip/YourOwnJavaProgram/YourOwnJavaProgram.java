public class YourOwnJavaProgram {
    public static void main(String[] args){
        System.out.println("My name is Jenny Shin");
        System.out.println("I am 18 years old");
        System.out.println("My hometown is Centreville, VA");
    }
}
