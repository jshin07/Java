package com.jenny.pets.models;

public interface Pet {
	String showAffection();
}
