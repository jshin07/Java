package com.jenny.thecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThecodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThecodeApplication.class, args);
	}
}
