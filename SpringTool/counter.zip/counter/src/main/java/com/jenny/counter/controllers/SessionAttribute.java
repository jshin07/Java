package com.jenny.counter.controllers;

public @interface SessionAttribute {

}
